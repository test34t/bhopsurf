#pragma once
// Física de movimento estilo Quake/GoldSrc, sem dependência do jogo.
// Unidades: metros e segundos (1 unidade do GoldSrc = 0,0254 m).
#include <math.h>

struct V3 { float x, y, z; };

struct MoveCfg {
    float airAccel     = 10.0f;  // sv_airaccelerate
    float airCap       = 0.76f;  // limite de "wishspeed" no ar (30 u do GoldSrc)
    float maxSpeed     = 7.0f;   // wishspeed máximo (corrida do CJ)
    float maxBhopSpeed = 0.0f;   // 0 = sem limite
    float surfMinNZ    = 0.05f;  // rampa mais íngreme que isso (parede = ~0)
    float surfMaxNZ    = 0.70f;  // rampa menos íngreme que isso (>= é chão)
    float surfPush     = 0.10f;  // empurrão (m/s) para fora da rampa
};

inline float HSpeed(const V3& v) { return sqrtf(v.x * v.x + v.y * v.y); }

// Direção desejada a partir da câmera (fx,fy) e do analógico (sx = direita, sy = frente), ambos em [-1,1].
inline bool WishDir(float fx, float fy, float sx, float sy,
                    float& wx, float& wy, float& mag)
{
    float fl = sqrtf(fx * fx + fy * fy);
    if (fl < 1e-4f) return false;
    fx /= fl; fy /= fl;
    float rx = fy, ry = -fx;                 // direita da câmera
    wx = fx * sy + rx * sx;
    wy = fy * sy + ry * sx;
    float l = sqrtf(wx * wx + wy * wy);
    if (l < 1e-4f) return false;
    mag = l > 1.0f ? 1.0f : l;
    wx /= l; wy /= l;
    return true;
}

// PM_AirAccelerate do GoldSrc: o limite de 30 u vale para a projeção da velocidade
// na direção desejada, e é isso que permite ganhar velocidade com air-strafe.
inline void AirAccelerate(V3& v, float wx, float wy, float wishSpeed,
                          const MoveCfg& c, float dt)
{
    float wishspd = wishSpeed < c.airCap ? wishSpeed : c.airCap;
    float cur = v.x * wx + v.y * wy;
    float add = wishspd - cur;
    if (add <= 0.0f) return;
    float acc = c.airAccel * wishSpeed * dt;
    if (acc > add) acc = add;
    v.x += acc * wx;
    v.y += acc * wy;
}

// PM_ClipVelocity: remove a componente da velocidade que entra no plano (surf).
inline bool ClipVelocity(V3& v, const V3& n, float push)
{
    float into = v.x * n.x + v.y * n.y + v.z * n.z;
    if (into >= 0.0f) return false;          // já está se afastando
    v.x -= n.x * into;
    v.y -= n.y * into;
    v.z -= n.z * into;
    v.x += n.x * push;
    v.y += n.y * push;
    v.z += n.z * push;
    return true;
}

inline void CapHSpeed(V3& v, float maxSpeed)
{
    if (maxSpeed <= 0.0f) return;
    float s = HSpeed(v);
    if (s > maxSpeed) { float k = maxSpeed / s; v.x *= k; v.y *= k; }
}
