#!/data/data/com.termux/files/usr/bin/bash
# Compila o BhopSurf (armeabi-v7a) direto no Termux, sem ndk-build.
# Uso:  NDK=~/android-ndk-r29 bash build_termux.sh
set -e
cd "$(dirname "$0")"

NDK="${NDK:-$HOME/android-ndk-r29}"
EXTRA=""

# procura o compilador em qualquer lugar do NDK (a estrutura varia entre builds)
CXX="${CXX:-$(find -L "$NDK" -maxdepth 8 -name 'armv7a-linux-androideabi21-clang++' 2>/dev/null | head -1)}"
if [ -z "$CXX" ]; then
  CXX=$(find -L "$NDK" -maxdepth 8 -name 'armv7a-linux-androideabi*-clang++' 2>/dev/null | sort | tail -1)
fi
if [ -z "$CXX" ]; then
  # sem o wrapper armv7a: usa o clang++ puro com --target e sysroot
  BASE=$(find -L "$NDK" -maxdepth 8 -name 'clang++' 2>/dev/null | head -1)
  if [ -n "$BASE" ]; then
    CXX="$BASE"
    EXTRA="--target=armv7a-linux-androideabi21 --sysroot=$(dirname "$BASE")/../sysroot"
  fi
fi
if [ -z "$CXX" ] || [ ! -e "$CXX" ]; then
  echo "ERRO: nao achei o clang++ dentro de $NDK"
  echo "--- conteudo de $NDK:"; ls "$NDK" 2>&1 | head -20
  echo "--- arquivos clang encontrados:"; find -L "$NDK" -maxdepth 8 -name '*clang*' 2>/dev/null | head -10
  exit 1
fi
echo "Usando: $CXX $EXTRA"

# headers do AML (so baixa se ainda nao existirem)
if [ ! -d jni/mod ]; then
  [ -d AndroidModLoader ] || git clone --depth 1 https://github.com/RusJJ/AndroidModLoader
  H=$(find AndroidModLoader -name amlmod.h | head -1)
  [ -n "$H" ] || { echo "ERRO: amlmod.h nao encontrado no repositorio do AML"; exit 1; }
  cp -r "$(dirname "$H")" jni/mod
fi

mkdir -p out
"$CXX" $EXTRA -shared -fPIC -DAML32 -std=c++17 -O2 -fno-exceptions -fno-rtti -static-libstdc++ \
  -Ijni jni/main.cpp $(ls jni/mod/*.cpp 2>/dev/null) -llog -o out/libBhopSurf.so

echo "OK: $(pwd)/out/libBhopSurf.so"
if [ -d "$HOME/storage/downloads" ]; then
  cp out/libBhopSurf.so "$HOME/storage/downloads/"
  echo "Copiado para a pasta Download do celular."
fi
