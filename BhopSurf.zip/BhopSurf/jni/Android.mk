LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE    := BhopSurf
# jni/mod/ vem do repositório do AML (amlmod.h, logger.h/.cpp, config.h/.cpp)
LOCAL_SRC_FILES := main.cpp $(patsubst $(LOCAL_PATH)/%,%,$(wildcard $(LOCAL_PATH)/mod/*.cpp))
LOCAL_C_INCLUDES += $(LOCAL_PATH)
LOCAL_CPPFLAGS  += -DAML32 -std=c++17 -O2 -fno-exceptions -fno-rtti
LOCAL_LDLIBS    += -llog
include $(BUILD_SHARED_LIBRARY)
