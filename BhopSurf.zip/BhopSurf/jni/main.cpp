// BhopSurf - mod AML para GTA San Andreas Android (libGTASA.so, ARM32)
// Movimentação estilo Quake/GoldSrc: air-strafe, auto-bhop e surf.
#include <mod/amlmod.h>
#include <mod/logger.h>
#include <mod/config.h>
#include <stdint.h>
#include "movement.h"

MYMODCFG(net.bhopsurf.gtasa, Bhop Surf Movement, 1.0.0, BhopSurf)

// CTimer::ms_fTimeStep == 1.0 equivale a 1/50 s; m_vecMoveSpeed é em unidades por esse passo.
static constexpr float kTickHz = 50.0f;

struct ColPoint { V3 point; float pad; V3 normal; uint8_t rest[112]; };

typedef void* (*FindPlayerPed_t)(int);
typedef void* (*FindPlayerVehicle_t)(int, bool);
typedef void* (*GetPad_t)(int);
typedef bool  (*ProcessLOS_t)(const V3&, const V3&, ColPoint&, void*&,
                              bool, bool, bool, bool, bool, bool, bool, bool);

static FindPlayerPed_t     FindPlayerPed;
static FindPlayerVehicle_t FindPlayerVehicle;
static GetPad_t            GetPad;
static ProcessLOS_t        ProcessLOS;
static float*              g_timeStep;
static uintptr_t           g_camera;          // &TheCamera
static void              (*Hooked_orig)();

static MoveCfg g_cfg;
static bool  g_enabled, g_autohop, g_surf, g_debug;
static float g_jumpSpeed, g_footDist, g_hopWindow;
static int   oMove, oPadX, oPadY, oPadJump, oCamMat;
static int   g_airTicks, g_dbgCounter;

// ---------------------------------------------------------------- colisão
static bool Ray(const V3& a, const V3& b, ColPoint& cp)
{
    void* ent = nullptr;
    // prédios, objetos; sem veículos/peds/dummies
    return ProcessLOS(a, b, cp, ent, true, false, false, true, false, false, false, false);
}

static bool IsSurfNormal(const ColPoint& c)
{
    return c.normal.z >= g_cfg.surfMinNZ && c.normal.z < g_cfg.surfMaxNZ;
}

// Procura rampas surfáveis embaixo e à frente (na direção da velocidade horizontal).
static int SurfNormals(const V3& pos, const V3& v, V3* out)
{
    int n = 0;
    ColPoint cp;

    V3 down = { pos.x, pos.y, pos.z - (g_footDist + 0.4f) };
    if (Ray(pos, down, cp) && IsSurfNormal(cp)) out[n++] = cp.normal;

    float hs = HSpeed(v);
    if (hs > 0.5f) {
        float dx = v.x / hs, dy = v.y / hs;
        const float heights[3] = { -0.6f, 0.0f, 0.5f };
        for (float h : heights) {
            V3 a = { pos.x, pos.y, pos.z + h };
            V3 b = { pos.x + dx * 0.6f, pos.y + dy * 0.6f, pos.z + h };
            if (n < 4 && Ray(a, b, cp) && IsSurfNormal(cp)) out[n++] = cp.normal;
        }
    }
    return n;
}

// ---------------------------------------------------------------- câmera
static bool CameraForward(float& fx, float& fy)
{
    if (!g_camera) return false;
    uintptr_t m = *(uintptr_t*)(g_camera + oCamMat);   // CPlaceable::m_matrix
    if (!m) return false;
    fx = *(float*)(m + 0x10);                          // CMatrix::up = frente
    fy = *(float*)(m + 0x14);
    return true;
}

// ---------------------------------------------------------------- tick
static void BhopTick()
{
    if (!g_enabled || !FindPlayerPed || !ProcessLOS || !g_timeStep) return;

    uintptr_t ped = (uintptr_t)FindPlayerPed(0);
    if (!ped) return;
    if (FindPlayerVehicle && FindPlayerVehicle(0, false)) { g_airTicks = 0; return; }

    float ts = *g_timeStep;
    if (!(ts > 0.0f) || ts > 10.0f) return;
    float dt = ts / kTickHz;

    uintptr_t mat = *(uintptr_t*)(ped + 0x14);         // CPlaceable::m_matrix
    if (!mat) return;
    V3 pos = *(V3*)(mat + 0x30);                       // CMatrix::pos

    float* mv = (float*)(ped + oMove);                 // CPhysical::m_vecMoveSpeed
    V3 v = { mv[0] * kTickHz, mv[1] * kTickHz, mv[2] * kTickHz };

    // input
    bool  jumpHeld = false;
    float sx = 0.0f, sy = 0.0f;
    uintptr_t pad = GetPad ? (uintptr_t)GetPad(0) : 0;
    if (pad) {
        jumpHeld = *(int16_t*)(pad + oPadJump) > 128;
        sx =  *(int16_t*)(pad + oPadX) / 128.0f;
        sy = -*(int16_t*)(pad + oPadY) / 128.0f;      // no GTA, frente = valor negativo
    }

    float fx = 0.0f, fy = 1.0f;
    if (!CameraForward(fx, fy)) { fx = *(float*)(mat + 0x10); fy = *(float*)(mat + 0x14); }

    // chão logo abaixo?
    ColPoint cp;
    V3 to = { pos.x, pos.y, pos.z - (g_footDist + g_hopWindow) };
    bool hit = Ray(pos, to, cp);
    float gDist = hit ? pos.z - cp.point.z : 1e9f;
    bool nearGround = hit && cp.normal.z >= g_cfg.surfMaxNZ && gDist <= g_footDist + g_hopWindow;

    // auto-bhop: pula de novo no instante do pouso, antes da engine "aterrissar" o CJ
    // (assim a velocidade horizontal nunca é zerada pela animação de pouso).
    // O primeiro pulo continua sendo o da própria engine.
    bool hopped = false;
    if (nearGround && v.z <= 0.0f) {
        if (g_autohop && jumpHeld && g_airTicks >= 3) { v.z = g_jumpSpeed; hopped = true; }
        else g_airTicks = 0;
    } else if (g_airTicks < 1000000) {
        g_airTicks++;
    }

    bool inAir = g_airTicks >= 1 || hopped;

    if (inAir) {
        float wx, wy, mag;
        if (WishDir(fx, fy, sx, sy, wx, wy, mag))
            AirAccelerate(v, wx, wy, mag * g_cfg.maxSpeed, g_cfg, dt);

        if (g_surf) {
            V3 n[4];
            int cnt = SurfNormals(pos, v, n);
            for (int i = 0; i < cnt; i++) ClipVelocity(v, n[i], g_cfg.surfPush);
        }

        CapHSpeed(v, g_cfg.maxBhopSpeed);

        mv[0] = v.x / kTickHz;
        mv[1] = v.y / kTickHz;
        mv[2] = v.z / kTickHz;
    }

    if (g_debug && (++g_dbgCounter % 25) == 0) {
        logger->Info("pos %.2f %.2f %.2f | vel %.2f %.2f %.2f (h=%.2f) | chao %.2f ar %d | stick %.2f %.2f pulo %d | cam %.2f %.2f",
                     pos.x, pos.y, pos.z, v.x, v.y, v.z, HSpeed(v), gDist, g_airTicks, sx, sy, jumpHeld, fx, fy);
        if (g_dbgCounter % 100 == 0) {           // ajuda a achar o offset de m_vecMoveSpeed
            float* p = (float*)(ped + 0x38);
            for (int i = 0; i < 16; i += 3)
                logger->Info("ped+%02X: %.3f %.3f %.3f", 0x38 + i * 4, p[i], p[i + 1], p[i + 2]);
        }
    }
}

static void Hooked()
{
    BhopTick();
    Hooked_orig();
}

// ---------------------------------------------------------------- entrada
extern "C" void OnModLoad()
{
    logger->SetTag("BhopSurf");

    g_enabled          = cfg->Bind("Enabled",      true,  "General")->GetBool();
    g_autohop          = cfg->Bind("AutoBhop",     true,  "General")->GetBool();
    g_surf             = cfg->Bind("Surf",         true,  "General")->GetBool();
    g_debug            = cfg->Bind("Debug",        false, "General")->GetBool();

    g_cfg.airAccel     = cfg->Bind("AirAccel",     10.0f, "Physics")->GetFloat();
    g_cfg.airCap       = cfg->Bind("AirCap",       0.76f, "Physics")->GetFloat();
    g_cfg.maxSpeed     = cfg->Bind("MaxSpeed",     7.0f,  "Physics")->GetFloat();
    g_cfg.maxBhopSpeed = cfg->Bind("MaxBhopSpeed", 0.0f,  "Physics")->GetFloat();
    g_cfg.surfMaxNZ    = cfg->Bind("SurfMaxNormalZ", 0.70f, "Physics")->GetFloat();
    g_cfg.surfPush     = cfg->Bind("SurfPush",     0.10f, "Physics")->GetFloat();
    g_jumpSpeed        = cfg->Bind("JumpSpeed",    6.5f,  "Physics")->GetFloat();   // m/s
    g_footDist         = cfg->Bind("FootDist",     1.0f,  "Physics")->GetFloat();   // centro do CJ ate o chao
    g_hopWindow        = cfg->Bind("HopWindow",    0.3f,  "Physics")->GetFloat();

    // offsets (decimal) - VERIFIQUE no seu libGTASA.so, veja o README
    oMove    = cfg->Bind("OffMoveSpeed", 68, "Offsets")->GetInt();   // 0x44 CPhysical::m_vecMoveSpeed
    oPadX    = cfg->Bind("OffPadStickX", 0,  "Offsets")->GetInt();   // CPad::NewState.LeftStickX
    oPadY    = cfg->Bind("OffPadStickY", 2,  "Offsets")->GetInt();   // CPad::NewState.LeftStickY
    oPadJump = cfg->Bind("OffPadJump",   28, "Offsets")->GetInt();   // 0x1C NewState.ButtonSquare
    oCamMat  = cfg->Bind("OffCamMatrix", 20, "Offsets")->GetInt();   // 0x14 CPlaceable::m_matrix
    cfg->Save();

    void* h = aml->GetLibHandle("libGTASA.so");
    if (!h) { logger->Error("libGTASA.so nao encontrada"); return; }

    FindPlayerPed     = (FindPlayerPed_t)    aml->GetSym(h, "_Z13FindPlayerPedi");
    FindPlayerVehicle = (FindPlayerVehicle_t)aml->GetSym(h, "_Z17FindPlayerVehicleib");
    GetPad            = (GetPad_t)           aml->GetSym(h, "_ZN4CPad6GetPadEi");
    ProcessLOS        = (ProcessLOS_t)       aml->GetSym(h, "_ZN6CWorld18ProcessLineOfSightERK7CVectorS2_R9CColPointRP7CEntitybbbbbbbb");
    g_timeStep        = (float*)             aml->GetSym(h, "_ZN6CTimer12ms_fTimeStepE");
    g_camera          = (uintptr_t)          aml->GetSym(h, "TheCamera");

    if (!FindPlayerPed || !ProcessLOS || !g_timeStep || !GetPad) {
        logger->Error("simbolos ausentes (FindPlayerPed=%p ProcessLOS=%p TimeStep=%p GetPad=%p) - mod desativado",
                      FindPlayerPed, ProcessLOS, g_timeStep, GetPad);
        return;
    }

    uintptr_t tick = (uintptr_t)aml->GetSym(h, "_ZN5CGame7ProcessEv");
    if (!tick) tick = (uintptr_t)aml->GetSym(h, "_ZN6CTimer6UpdateEv");
    if (!tick) { logger->Error("nao achei funcao de tick para hookar"); return; }

    aml->Hook((void*)tick, (void*)Hooked, (void**)&Hooked_orig);
    logger->Info("BhopSurf carregado");
}
