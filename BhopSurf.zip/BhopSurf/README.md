# BhopSurf (mod AML, GTA SA Android)

Movimentação estilo Quake/GoldSrc para o CJ: air-strafe, auto-bhop e surf em rampas.
Alvo: `libGTASA.so` 2.00 ARM32, com o Android Mod Loader (AML) instalado.

## Como compilar
1. Baixe o repositório do AML (RusJJ/AndroidModLoader) e copie a pasta `mod/` (headers `amlmod.h`, `logger.h`, `config.h`; veja dentro de `template_of_mod`) para `jni/mod/`.
2. Na pasta do projeto: `ndk-build` (precisa do Android NDK).
3. Copie `libs/armeabi-v7a/libBhopSurf.so` para a pasta de mods do AML:
   `Android/data/com.rockstargames.gtasa/mods/` (crie a pasta `mods` se não existir)
4. Abra o jogo. No primeiro start o AML gera o `.ini` na pasta de configs com todas as opções.

## Compilar no Termux (sem ndk-build)
1. Termux da F-Droid ou do GitHub; NDK para aarch64: github.com/lzhiyong/termux-ndk (releases).
2. `termux-setup-storage`, depois `pkg install git unzip`.
3. Extraia o NDK em `~/android-ndk-r29` e este zip em `~/BhopSurf`.
4. `cd ~/BhopSurf && NDK=~/android-ndk-r29 bash build_termux.sh`
5. O `.so` fica em `out/` e é copiado para a pasta Download.

## Compilar pelo GitHub Actions (sem NDK no celular)
1. Crie um repositório no GitHub e envie o `BhopSurf.zip` para a raiz (Add file > Upload files).
2. Crie o arquivo `.github/workflows/build.yml` com o workflow que acompanha a conversa.
3. Aba Actions > execução mais recente > Artifacts > baixe `libBhopSurf` (é um zip com o `.so`).

## Como funciona
- **Air-strafe**: `PM_AirAccelerate` do GoldSrc. O analógico esquerdo define a direção e a câmera define o "olhar"; segure um lado e gire a câmera para ganhar velocidade.
- **Auto-bhop**: segurando o botão de pulo, o mod pula de novo no instante do pouso, antes da engine aplicar a animação de pouso. O primeiro pulo continua sendo o normal do jogo.
- **Surf**: em rampas com normal.z entre `0.05` e `0.70` a velocidade é projetada no plano da rampa (`PM_ClipVelocity`), sem perder velocidade.

## Calibração (importante)
Os offsets e símbolos abaixo vêm das estruturas do GTA SA e **precisam ser conferidos** no seu `libGTASA.so`.

1. Símbolos: `readelf -Ws --dyn-syms libGTASA.so | grep -E "FindPlayerPed|GetPad|ProcessLineOfSight|ms_fTimeStep|CGame7Process|TheCamera"`.
   Se algum faltar, o mod loga o erro e se desativa sozinho.
2. Ligue `Debug=true` no `.ini` e veja `adb logcat -s BhopSurf`:
   - `vel` deve ficar perto de 0 parado e subir até ~5 a 7 m/s correndo. Se ficar sempre 0, o `OffMoveSpeed` está errado: nas linhas `ped+XX` procure o trio de floats que muda quando o CJ anda e use esse offset (decimal).
   - `stick` deve mudar ao mexer o analógico e `pulo` deve virar 1 ao apertar pular (`OffPadStickX/Y`, `OffPadJump`).
   - `cam` deve mudar ao girar a câmera (`OffCamMatrix`).
3. Ajuste fino: `AirAccel`, `AirCap` (maior = mais ganho no ar), `MaxBhopSpeed` (0 = sem limite), `JumpSpeed`, `SurfMaxNormalZ`.

## Limitações
- Só funciona a pé, no modo single-player (`libGTASA.so`). Não funciona em SA-MP/MTA.
- O CJ continua com as animações do jogo (cair, deslizar em rampa íngreme), então o visual não é igual ao do CS.
- O ganho de velocidade no ar depende do FPS, como no GoldSrc original.
- ARM64 (libGTASA 2.10) não é suportado: os offsets de ponteiros são diferentes.
